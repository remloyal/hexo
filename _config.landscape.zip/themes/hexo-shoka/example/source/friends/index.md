---
title: 友情链接
keywords: 友情链接
description: 霜月琉璃的小伙伴们
copyright: false
---

# 本站信息
- 站名： 優萌初華
- 站长： 霜月琉璃
- 地址： https://shoka.lostyu.me
- 标志： ![霜月琉璃](https://cdn.jsdelivr.net/gh/amehime/shoka@latest/images/avatar.jpg){height="100" width="100"}
- 简介： 琉璃的医学 & 编程笔记

# 申请方法
- 添加本站后，在本页留言，格式如下

~~~yml
```yml
- site: #网站的名字
  owner: #您的名字
  url: #您的网址
  desc: #简短描述
  image: #一张图片
  color: #方块颜色
```
~~~

# 小伙伴们
{% linksfile friends/_data.yml %}

